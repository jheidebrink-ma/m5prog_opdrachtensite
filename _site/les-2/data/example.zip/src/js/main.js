
import 'bootstrap';

console.log('init M5PROG');
